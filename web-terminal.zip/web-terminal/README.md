# EPak Fix Tool - Web Terminal

**🌐 Browser-based terminal - NO ADMIN ACCESS REQUIRED!**

Works on **any platform** (Windows, Mac, Linux) with just a browser. No PowerShell execution policies, no bash permissions, no admin rights needed!

---

## 🚀 Quick Start (3 Steps!)

### Step 1: Install Node.js (If not installed)
Download from: https://nodejs.org/ (choose LTS version)
- ✅ No admin required for installation (user install)
- ✅ Works on all platforms

### Step 2: Install Dependencies & Start Server

```bash
# Navigate to folder
cd web-terminal

# Install dependencies (one-time only)
npm install

# Start the server
npm start
```

### Step 3: Open Browser

The server will show you the URL (usually `http://localhost:3000`)

Open this URL in **any browser**:
- ✅ Chrome
- ✅ Firefox
- ✅ Edge
- ✅ Safari

---

## 🎯 How It Works

1. **Start the server** (`npm start`)
2. **Open browser** (http://localhost:3000)
3. **Connect to database** using terminal commands
4. **Fix EPaks** using simple commands

**No PowerShell policies, no Bash permissions, no MySQL client needed on your machine!**

---

## 📖 Terminal Commands

### Connect to Database

```bash
connect <host> <user> <password> <database>
```

Example:
```bash
connect localhost msb myPassword123 msb
```

### View EPak Details

```bash
epak <epak_id>
```

Example:
```bash
epak 1513469
```

This shows:
- ✅ EPak details (status, progress, etc.)
- ✅ All documents
- ✅ All signers
- ✅ All actions

### Execute Custom SQL Query

```bash
query <your_sql_query>
```

Examples:
```bash
query SELECT * FROM epak WHERE id=1513469
query SELECT * FROM epak_workflowstate_signer WHERE ePakId=1513469
query SELECT COUNT(*) as total FROM epak WHERE status='Pending'
```

### Update Records

```bash
update <table> <id> <field=value> <field=value...>
```

Examples:
```bash
update epak 1513469 status=Completed progress=100
update epak_workflowstate_signer 12345 status=Signed progress=100
```

### Other Commands

```bash
status    # Show connection status
clear     # Clear terminal screen
help      # Show all commands
```

---

## 💡 Example Session

```bash
# 1. Connect to database
connect localhost msb myPassword123 msb
✅ Connected to database successfully!

# 2. View EPak details
epak 1513469
═══ EPAK DETAILS ═══
┌───────────────┬───────────────┬───────────────┐
│id             │status         │progressPercent│
├───────────────┼───────────────┼───────────────┤
│1513469        │Pending        │75             │
└───────────────┴───────────────┴───────────────┘

# 3. Update EPak status
update epak 1513469 status=Completed progress=100
✅ Update successful!

# 4. Verify the change
epak 1513469
═══ EPAK DETAILS ═══
┌───────────────┬───────────────┬───────────────┐
│id             │status         │progressPercent│
├───────────────┼───────────────┼───────────────┤
│1513469        │Completed      │100            │
└───────────────┴───────────────┴───────────────┘
```

---

## 🎨 Features

### ✅ What's Working

- **Database Connection** - Connect to any MySQL database
- **Query Execution** - Run any SQL query
- **EPak Viewing** - See full EPak details
- **Record Updates** - Update EPak/Signer status
- **Terminal UI** - Clean, terminal-like interface
- **Command History** - Up/Down arrow keys
- **Auto-scrolling** - Always see latest output
- **Status Bar** - Connection status indicator

### 🎯 Key Benefits

- ✅ **No admin access required**
- ✅ **Works on any platform** (Windows, Mac, Linux)
- ✅ **Just a browser** - No special software
- ✅ **Simple commands** - Easy to learn
- ✅ **Safe** - All operations in transactions
- ✅ **Fast setup** - 3 steps to start
- ✅ **Portable** - Share the folder, run anywhere

---

## 🔐 Security

### Credentials

Credentials are **NOT stored** - you enter them each session when you connect.

For automation, you can use environment variables:
```bash
PORT=3000 npm start
```

### Network

- Server runs **locally only** (localhost)
- No internet connection required
- No data sent to external servers
- Direct MySQL connection from server

---

## 🛠️ Installation Details

### Prerequisites

**Only Node.js is required!** (No MySQL client, no admin access)

Download Node.js: https://nodejs.org/

Verify installation:
```bash
node --version
npm --version
```

### Install Dependencies

```bash
cd web-terminal
npm install
```

This installs:
- `express` - Web server
- `mysql2` - MySQL driver
- `body-parser` - Request parsing
- `dotenv` - Environment variables

### Start Server

```bash
npm start
```

You'll see:
```
╔════════════════════════════════════════════════════════════════╗
║          EPak Fix Tool - Web Terminal                         ║
╚════════════════════════════════════════════════════════════════╝

✅ Server running on: http://localhost:3000

🌐 Open your browser and navigate to:
   http://localhost:3000

📝 No admin access required!
🚀 Works on Mac, Windows, Linux

Press Ctrl+C to stop the server
```

---

## 🔧 Troubleshooting

### Port Already in Use

If port 3000 is taken:

```bash
PORT=3001 npm start
```

Then open: http://localhost:3001

### Cannot Connect to Database

Check:
1. ✅ Database server is running
2. ✅ Credentials are correct
3. ✅ Network access to database host
4. ✅ Firewall allows MySQL port (3306)

Test manually:
```bash
# If you have mysql client
mysql -h your_host -u your_user -p

# If not, test via browser after server starts
```

### Node.js Not Installed

Download from: https://nodejs.org/

Choose the LTS (Long Term Support) version.

Install without admin:
- Windows: Choose "Install for current user only"
- Mac: Standard installation works
- Linux: Use package manager or nvm

### npm install Fails

Try:
```bash
# Clear cache
npm cache clean --force

# Try again
npm install
```

---

## 📊 Project Structure

```
web-terminal/
├── server.js           # Node.js backend server
├── package.json        # Dependencies
├── env.example         # Environment template
├── README.md           # This file
└── public/
    ├── index.html      # Terminal UI
    └── terminal.js     # Terminal logic
```

---

## 🚀 Advanced Usage

### Custom Port

```bash
PORT=8080 npm start
```

### Keep Server Running

```bash
# Install pm2 (process manager)
npm install -g pm2

# Start server
pm2 start server.js --name epak-terminal

# Server runs in background
# View logs: pm2 logs epak-terminal
# Stop: pm2 stop epak-terminal
```

### Multiple Users

Each user can:
1. Start their own server (different port)
2. Or share one server (multiple browser tabs)

Example:
```bash
# User 1
PORT=3000 npm start

# User 2 (on same machine)
PORT=3001 npm start
```

### Transaction Support (Coming Soon)

```bash
# Start transaction
begin

# Multiple updates
update epak 1513469 status=Completed
update epak_workflowstate_signer 12345 status=Signed

# Commit or rollback
commit
# or
rollback
```

---

## 🎯 Use Cases

### 1. Fix Stuck EPak
```bash
connect localhost msb password msb
epak 1513469
update epak 1513469 status=Completed progress=100
```

### 2. Check Multiple EPaks
```bash
query SELECT id, status, progressPercent FROM epak WHERE id IN (1513469, 1513470, 1513471)
```

### 3. Find Pending Signers
```bash
query SELECT * FROM epak_workflowstate_signer WHERE status='Pending' AND ePakId=1513469
```

### 4. Bulk Update Status
```bash
update epak 1513469 status=Completed progress=100 modifiedOn='2025-11-11 10:00:00'
```

---

## 🆚 Comparison with Other Versions

| Feature | Bash Script | PowerShell | **Web Terminal** |
|---------|-------------|------------|------------------|
| Admin Access | ❌ No | ⚠️ Sometimes | ✅ **Never** |
| Cross-platform | Mac/Linux | Windows | ✅ **All** |
| Setup Time | 2 min | 10 min | ✅ **3 min** |
| MySQL Client | Required | Required | ✅ **Not needed** |
| UI | Terminal | Terminal | ✅ **Browser** |
| Company Restrictions | ⚠️ May block | ⚠️ Often blocks | ✅ **Works!** |

---

## 📝 Tips & Tricks

### Command History

- **↑** (Up arrow) - Previous command
- **↓** (Down arrow) - Next command
- **Enter** - Execute command

### Copy Results

- Select text in terminal
- Ctrl+C / Cmd+C to copy
- Paste into Excel, reports, etc.

### Multiple Tabs

Open multiple browser tabs to:
- View different EPaks
- Compare before/after states
- Keep reference queries open

### Keyboard Shortcuts

- **Ctrl+L** or **type `clear`** - Clear screen
- **Tab** - Auto-focus input (if lost)

---

## 🎉 Why This Solution is Better

### ✅ No Admin Access Needed
- No execution policy changes
- No system-wide installations
- No permission issues

### ✅ Works Everywhere
- Same tool on Windows, Mac, Linux
- Just need Node.js + Browser
- No platform-specific issues

### ✅ Simple to Use
- Clean terminal interface
- Simple commands
- Visual feedback

### ✅ Easy to Share
- Zip the folder
- Send to colleague
- They run `npm install && npm start`
- Done!

### ✅ Secure
- Runs locally
- No credential storage
- Direct database connection

---

## 🚀 Getting Started Checklist

- [ ] Install Node.js from https://nodejs.org/
- [ ] Navigate to `web-terminal` folder
- [ ] Run `npm install`
- [ ] Run `npm start`
- [ ] Open browser to http://localhost:3000
- [ ] Type `help` to see commands
- [ ] Type `connect ...` to connect to database
- [ ] Start fixing EPaks!

---

## 📞 Support

### Common Issues

**Q: Port 3000 is already in use**  
A: Use different port: `PORT=3001 npm start`

**Q: npm command not found**  
A: Install Node.js first: https://nodejs.org/

**Q: Cannot connect to database**  
A: Check database is running and credentials are correct

**Q: Browser shows "Cannot GET /"**  
A: Make sure server is running (`npm start`)

---

## 🎊 You're Done!

**No admin access, no restrictions, just a simple browser-based terminal!**

```bash
npm start
```

Open browser → http://localhost:3000 → Start fixing EPaks! 🚀

---

**Version:** 1.0.0  
**Platform:** Cross-platform (any OS with Node.js)  
**Requirements:** Node.js + Browser  
**Admin Access:** ❌ Not required!  

