#!/bin/bash
# EPak Web Terminal - Quick Start Script
# Works on Mac, Linux, and Git Bash on Windows

clear

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║          EPak Fix Tool - Web Terminal Launcher                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo ""
    echo "Please install Node.js from: https://nodejs.org/"
    echo ""
    echo "After installation, run this script again."
    echo ""
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo ""

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies (first time only)..."
    echo ""
    npm install
    echo ""
fi

echo "🚀 Starting EPak Web Terminal..."
echo ""
echo "The server will start in a moment."
echo "Your browser will show the terminal interface."
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

# Start the server
npm start

